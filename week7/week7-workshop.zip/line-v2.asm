// Should start with R0=1, then toggle between 0 and 1 whenever 'm' is pressed.
// RAM[0] = 1;
@R0
M=1
// mpressed = 0;
@mpressed
M=0

// while(true) {
(infloop)


//  if (RAM[KBD] == 109) {
@KBD // Reads as @0x6000
D=M
// We want to jump if D==109, i.e. D-109==0
@109
D=D-A
@else
D;JNE

//     if (mpressed == 0) {
@mpressed
D=M
@endifelse
D;JNE

//       mpressed = 1;
@mpressed
M=1
//       RAM[0] = 1 - RAM[0];
@1
D=A
@R0
M=D-M

//    }
//  } else { 
@endifelse
0;JMP
(else)

//     if (mpressed == 1) {
@mpressed
D=M-1
@endifelse
D;JNE
//       mpressed = 0;
@mpressed
M=0
//     }
//  }
(endifelse)

// }
@infloop
0;JMP
(infloopend)

