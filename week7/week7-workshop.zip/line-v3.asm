// Should start a diagonal line drawn from the top-left corner of the screen, 
// then toggle it on or off when 'm' is pressed.
// drawline = 1;
@drawline
M=1
// mpressed = 0;
@mpressed
M=0

// while(true) {
(infloop)


//  if (RAM[KBD] == 109) {
@KBD 
D=M
@109
D=D-A
@else
D;JNE

//     if (mpressed == 0) {
@mpressed
D=M
@endifelse
D;JNE

//       mpressed = 1;
@mpressed
M=1
//       drawline = 1 - drawline;
@1
D=A
@drawline
M=D-M

//    }
//  } else { 
@endifelse
0;JMP
(else)

//     if (mpressed == 1) {
@mpressed
D=M-1
@endifelse
D;JNE
//       mpressed = 0;
@mpressed
M=0
//     }
//  }
(endifelse)

// Draw the line if needed
//   if (drawline == 1) {
@drawline
D=M-1
@clearscreen
D;JNE

//     int addr = 0x4000;
@SCREEN
D=A
@addr
M=D

//     int i = 0;
@i
M=0

//     while (i < 16) {
(outerlineloop)
@i
D=M
@16
D=D-A
@outerlineloopend
D;JGE

//       int towrite = 1;
@towrite
M=1

//       int j = 0;
@j
M=0

//       while (j < 16) {
(innerlineloop)
@j
D=M
@16
D=D-A
@innerlineloopend
D;JGE

//         RAM[addr] = towrite;
@towrite
D=M
@addr
A=M
M=D

//         addr += 32;
@32
D=A
@addr
M=M+D

//         towrite *= 2;
@towrite
D=M
M=M+D

//         j++;
@j
M=M+1

//       }
@innerlineloop
0;JMP
(innerlineloopend)

//       addr++;
@addr
M=M+1

//       i++;
@i
M=M+1

//     }
@outerlineloop
0;JMP
(outerlineloopend)
  
// Clear the screen if needed
//   } else {
@endloop
0;JMP
(clearscreen)

//     int addr = 0x4000;
@SCREEN
D=A
@addr
M=D

//     while (addr < 0x6000) {
(clearloop)
@addr
D=M
@KBD
D=D-A
@endclearloop
D;JGE

//       RAM[addr] = 0;
@addr
A=M
M=0

//       addr++;
@addr
M=M+1

//     }
@clearloop
0;JMP
(endclearloop)

//   }
(endloop)

// }
@infloop
0;JMP
(infloopend)

