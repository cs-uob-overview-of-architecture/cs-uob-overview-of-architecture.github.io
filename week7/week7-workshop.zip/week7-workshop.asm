// Should start with R0=1, then toggle between 0 and 1 whenever 'm' is pressed.
// Doesn't actually work - instead R0 is set randomly whenever 'm' is pressed.
// RAM[0] = 1;
@R0
M=1

// while(true) {
(infloop)

//  if (RAM[KBD] == 109) {
@KBD // Reads as @0x6000
D=M
// We want to jump if D==109, i.e. D-109==0
@109
D=D-A
@mnotpressed
D;JNE

//     RAM[0] = 1 - RAM[0]
@1
D=A
@R0
M=D-M

//   }
(mnotpressed)
// }
@infloop
0;JMP
(infloopend)

